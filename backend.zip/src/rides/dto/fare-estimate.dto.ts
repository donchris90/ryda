import { IsBoolean, IsEnum, IsNumber, IsOptional, IsString, ValidateNested, ArrayMaxSize } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { RideCategory } from '../../common/enums/ride.enum';
import { RideStopDto } from './request-ride.dto';

export class FareEstimateDto {
  @ApiProperty({ enum: RideCategory, example: RideCategory.ECONOMY })
  @IsEnum(RideCategory)
  category: RideCategory;

  @ApiProperty({ example: 6.6018 })
  @IsNumber()
  pickupLat: number;

  @ApiProperty({ example: 3.3515 })
  @IsNumber()
  pickupLng: number;

  @ApiProperty({ example: 6.4281 })
  @IsNumber()
  dropoffLat: number;

  @ApiProperty({ example: 3.4219 })
  @IsNumber()
  dropoffLng: number;

  @ApiPropertyOptional({ example: 'Lagos', description: 'Used for surge calculation and night/airport pricing' })
  @IsOptional()
  @IsString()
  city?: string;

  @ApiPropertyOptional({ description: 'Adds the flat airport surcharge' })
  @IsOptional()
  @IsBoolean()
  isAirportTrip?: boolean;

  @ApiPropertyOptional({ type: [RideStopDto], description: 'Intermediate stops in visit order, between pickup and dropoff' })
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => RideStopDto)
  @ArrayMaxSize(3)
  stops?: RideStopDto[];

  // Mirrors RequestRideDto's own field - lets the estimate reflect the
  // pool discount up front (see RidesService.estimateFare()'s own
  // comment on why this is safe to show even though the actual
  // discount only ever really applies once a match succeeds).
  @ApiPropertyOptional({ description: 'Preview the fare as if this ride opts into shared/pooled matching' })
  @IsOptional()
  @IsBoolean()
  isPooled?: boolean;
}
