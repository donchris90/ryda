import {
  BadRequestException,
  ConflictException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, MoreThan } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { createHash, randomUUID } from 'crypto';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { OtpPurpose } from '../otp/otp-code.entity';
import { OtpService } from '../otp/otp.service';
import { AuthTokensService } from './auth-tokens.service';
import { AuthTokenPurpose } from './entities/auth-token.entity';
import { MailerService } from '../mailer/mailer.service';
import { RefreshToken } from './entities/refresh-token.entity';
import { User } from '../users/entities/user.entity';
import { UsersService } from '../users/users.service';
import { UserRole, SELF_REGISTERABLE_ROLES } from '../common/enums/user-role.enum';
import { WalletsService } from '../wallets/wallets.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { SendOtpDto, VerifyOtpDto } from './dto/otp.dto';
import { AuditService } from '../audit/audit.service';
import { FraudService } from '../fraud/fraud.service';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationChannel, NotificationCategory } from '../notifications/entities/notification.entity';

/**
 * Captured at login and at every refresh-rotation, threaded down from
 * the controller's request object. Everything optional - a missing
 * piece (no fingerprint sent, IP unavailable behind some proxy setup)
 * still issues the token, just with a less descriptive session row.
 */
export interface SessionContext {
  deviceFingerprint?: string;
  ipAddress?: string;
  userAgent?: string;
}

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(RefreshToken)
    private readonly refreshTokenRepo: Repository<RefreshToken>,
    private readonly usersService: UsersService,
    private readonly walletsService: WalletsService,
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
    private readonly auditService: AuditService,
    private readonly fraudService: FraudService,
    private readonly notificationsService: NotificationsService,
    private readonly otpService: OtpService,
    private readonly authTokensService: AuthTokensService,
    private readonly mailerService: MailerService,
  ) {}

  async register(dto: RegisterDto) {
    // Defense in depth, not the only guard - the DTO's own @IsIn()
    // already rejects this at the validation-pipe layer, but a
    // security-critical check like "never let self-registration grant
    // staff access" belongs enforced at the service level too, not
    // solely trusted to a decorator staying correctly configured on
    // this one DTO forever.
    if (dto.role && !SELF_REGISTERABLE_ROLES.includes(dto.role)) {
      throw new BadRequestException('Staff roles cannot be self-registered.');
    }

    const existingByEmail = await this.usersService.findByEmail(dto.email);
    if (existingByEmail) {
      // Same person wanting a second role (e.g. registered as a passenger,
      // now trying to sign up as a driver) shouldn't create a second
      // account — but we also can't silently graft a role onto an
      // existing account from an unauthenticated register call, since
      // that would let anyone add a role to someone else's account just
      // by knowing their email. Point them at the authenticated flow.
      throw new ConflictException(
        'An account already exists with this email. Please log in and use "Add role" ' +
          'from your profile to also register as a driver, instead of creating a new account.',
      );
    }

    if (dto.phone) {
      const existingByPhone = await this.usersService.findByPhone(dto.phone);
      if (existingByPhone) throw new ConflictException('Phone number already registered');
    }

    const passwordHash = await bcrypt.hash(dto.password, 10);

    const user = await this.usersService.create({
      email: dto.email,
      phone: dto.phone ?? null,
      passwordHash,
      firstName: dto.firstName,
      lastName: dto.lastName,
      role: dto.role,
      referredByCode: dto.referralCode ?? null,
    });

    await this.walletsService.createForUser(user.id);

    if (dto.deviceFingerprint) {
      await this.fraudService.recordDeviceFingerprint(user.id, dto.deviceFingerprint);
    }

    await this.sendVerificationEmail(user.id, user.email, user.firstName);

    // Deliberately no tokens issued here - matches the requested flow
    // (register -> verify -> login), not an auto-logged-in state for
    // an account that hasn't proven its email yet.
    return {
      message: 'Registration successful — check your email to verify your account before logging in.',
      userId: user.id,
    };
  }

  async sendVerificationEmail(userId: string, email: string, firstName: string): Promise<void> {
    const token = await this.authTokensService.issue(userId, AuthTokenPurpose.EMAIL_VERIFICATION);
    const appBaseUrl = this.config.get<string>('mail.appBaseUrl')!;
    const verifyUrl = `${appBaseUrl}/verify-email?token=${token}`;

    await this.mailerService.send(
      email,
      'Verify your Ryda account',
      `<p>Hi ${firstName},</p>
       <p>Welcome to Ryda. Click the link below to verify your email and activate your account:</p>
       <p><a href="${verifyUrl}">Verify my email</a></p>
       <p>This link expires in ${this.config.get<number>('mail.verificationTtlHours')} hours. If you didn't create this account, you can ignore this email.</p>`,
    );
  }

  async resendVerificationEmail(email: string): Promise<{ message: string }> {
    const user = await this.usersService.findByEmail(email);
    // Same message whether or not the account exists — confirming or
    // denying an email's registration status to an unauthenticated
    // caller is its own minor information leak, not worth it here.
    if (!user || user.isEmailVerified) {
      return { message: 'If that email is registered and unverified, a new verification link has been sent.' };
    }

    await this.sendVerificationEmail(user.id, user.email, user.firstName);
    return { message: 'If that email is registered and unverified, a new verification link has been sent.' };
  }

  async verifyEmail(token: string): Promise<{ verified: true }> {
    const userId = await this.authTokensService.consume(token, AuthTokenPurpose.EMAIL_VERIFICATION);
    await this.usersService.markEmailVerified(userId);
    return { verified: true };
  }

  async forgotPassword(email: string): Promise<{ message: string }> {
    const user = await this.usersService.findByEmail(email);
    // Same response whether or not the account exists — same reasoning
    // as resendVerificationEmail above.
    if (!user) {
      return { message: 'If that email is registered, a password reset link has been sent.' };
    }

    const token = await this.authTokensService.issue(user.id, AuthTokenPurpose.PASSWORD_RESET);
    const appBaseUrl = this.config.get<string>('mail.appBaseUrl')!;
    const resetUrl = `${appBaseUrl}/reset-password?token=${token}`;

    await this.mailerService.send(
      user.email,
      'Reset your Ryda password',
      `<p>Hi ${user.firstName},</p>
       <p>Click the link below to reset your password:</p>
       <p><a href="${resetUrl}">Reset my password</a></p>
       <p>This link expires in ${this.config.get<number>('mail.passwordResetTtlMinutes')} minutes. If you didn't request this, you can ignore this email — your password will not be changed.</p>`,
    );

    return { message: 'If that email is registered, a password reset link has been sent.' };
  }

  async resetPassword(token: string, newPassword: string): Promise<{ message: string }> {
    const userId = await this.authTokensService.consume(token, AuthTokenPurpose.PASSWORD_RESET);
    const passwordHash = await bcrypt.hash(newPassword, 10);
    await this.usersService.updatePasswordHash(userId, passwordHash);
    // Revoking every existing refresh token means a stolen device or
    // leaked session can't keep riding on the old password after a
    // reset - the whole point of a reset is to cut off prior access.
    await this.logoutAll(userId);
    return { message: 'Password reset successfully — please log in with your new password.' };
  }

  async changePassword(userId: string, currentPassword: string, newPassword: string): Promise<{ message: string }> {
    const user = await this.usersService.findByIdWithPassword(userId);
    if (!user?.passwordHash || !(await bcrypt.compare(currentPassword, user.passwordHash))) {
      throw new UnauthorizedException('Current password is incorrect');
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);
    await this.usersService.updatePasswordHash(userId, passwordHash);
    // Same reasoning as resetPassword() — revoking every session,
    // including this one, means a leaked old password on another
    // device loses access too, not just newly-issued tokens. The
    // person just re-proved they know the (old) password, so a fresh
    // login here is a small, reasonable cost for that guarantee.
    await this.logoutAll(userId);
    return { message: 'Password changed — please log in again with your new password.' };
  }

  async deleteAccount(userId: string, password: string): Promise<{ message: string }> {
    const user = await this.usersService.findByIdWithPassword(userId);
    if (!user?.passwordHash || !(await bcrypt.compare(password, user.passwordHash))) {
      throw new UnauthorizedException('Password is incorrect');
    }

    // Soft deactivation, not a row delete — the spec is explicit that
    // this shouldn't just delete the database row immediately, and for
    // good reason: a hard delete would either cascade-fail against
    // every ride/wallet-transaction/document row referencing this
    // user, or silently orphan/corrupt another passenger's or driver's
    // own ride history, financial records, and audit trail, none of
    // which is this account's data to take down with it. isActive=false
    // plus a full session revocation is sufficient to make the account
    // genuinely unusable — login() already rejects a disabled account
    // (see the isActive check there) — while leaving every historical
    // record intact for the people who legitimately still need it.
    await this.usersService.deactivate(userId);
    await this.logoutAll(userId);
    return { message: 'Your account has been deactivated.' };
  }

  async sendOtp(dto: SendOtpDto, purpose: OtpPurpose = OtpPurpose.PHONE_VERIFICATION) {
    const { devOnlyCode, expiresInSeconds } = await this.otpService.send(dto.phone, purpose);
    return { message: 'OTP sent', devOnlyCode, expiresInSeconds };
  }

  async verifyOtp(dto: VerifyOtpDto, purpose: OtpPurpose = OtpPurpose.PHONE_VERIFICATION) {
    await this.otpService.verify(dto.phone, dto.code, purpose);

    // Only a genuine phone-verification OTP should ever mark the phone
    // verified - a wallet-transfer confirmation succeeding says nothing
    // about phone ownership being newly proven, it was already required
    // to be verified before a transfer OTP could even be requested.
    if (purpose === OtpPurpose.PHONE_VERIFICATION) {
      const user = await this.usersService.findByPhone(dto.phone);
      if (user) {
        await this.usersService.markPhoneVerified(user.id);
      }
    }

    return { verified: true };
  }

  async login(dto: LoginDto, context: SessionContext = {}) {
    const user = await this.usersService.findByEmailWithPassword(dto.email);
    if (!user || !user.passwordHash) {
      await this.auditService.log({
        actorUserId: null,
        actorRole: null,
        action: 'auth.login.failed',
        metadata: { identifier: dto.email, reason: 'unknown_account' },
      });
      throw new UnauthorizedException('Invalid credentials');
    }

    const passwordMatches = await bcrypt.compare(dto.password, user.passwordHash);
    if (!passwordMatches) {
      await this.auditService.log({
        actorUserId: user.id,
        actorRole: user.role,
        action: 'auth.login.failed',
        metadata: { identifier: dto.email, reason: 'bad_password' },
      });
      throw new UnauthorizedException('Invalid credentials');
    }
    if (!user.isActive) {
      throw new UnauthorizedException('Account is disabled');
    }

    // Matches the requested flow directly: verify before login, not
    // verify-or-be-silently-limited-once-in. A correct password for an
    // unverified account gets a specific, actionable error rather than
    // a generic failure or a silent partial login.
    if (!user.isEmailVerified) {
      throw new UnauthorizedException('Please verify your email before logging in — check your inbox for the verification link.');
    }

    await this.auditService.log({
      actorUserId: user.id,
      actorRole: user.role,
      action: 'auth.login.success',
    });

    if (dto.deviceFingerprint) {
      const { isNewDevice } = await this.fraudService.recordDeviceFingerprint(
        user.id,
        dto.deviceFingerprint,
        context.ipAddress,
      );
      if (isNewDevice) {
        // Best-effort, deliberately not awaited into a failure path -
        // a notification-send hiccup must never block a legitimate
        // login. In-app + email only: this isn't urgent enough to
        // justify SMS cost, and a security notice landing in email is
        // the conventional place a user would expect to find it.
        this.notificationsService
          .notify(
            user.id,
            [NotificationChannel.IN_APP, NotificationChannel.EMAIL],
            'New login to your account',
            `Your account was just signed in to from a new device${context.ipAddress ? ` (IP ${context.ipAddress})` : ''}. If this wasn't you, change your password immediately.`,
            undefined,
            NotificationCategory.SECURITY,
          )
          .catch(() => undefined);
      }
    }

    const tokens = await this.issueTokens(user.id, user.role, context);
    return { user: this.sanitizeUser(user), ...tokens };
  }

  /**
   * Verifies + rotates a refresh token: the presented token is checked
   * against its stored hash and must not already be revoked. If a *revoked*
   * token is presented, that's a signal of possible theft (an old token
   * being replayed), so every refresh token for that user is revoked as a
   * precaution and the caller must log in again.
   */
  async refresh(refreshToken: string, context: SessionContext = {}) {
    let payload: { sub: string; role: string };
    try {
      payload = this.jwtService.verify(refreshToken, {
        secret: this.config.get<string>('jwt.refreshSecret'),
      });
    } catch {
      throw new UnauthorizedException('Invalid refresh token');
    }

    const tokenHash = this.hashToken(refreshToken);
    const stored = await this.refreshTokenRepo.findOne({ where: { tokenHash } });

    if (!stored || stored.expiresAt < new Date()) {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }
    if (stored.revoked) {
      await this.refreshTokenRepo.update({ userId: stored.userId }, { revoked: true });
      throw new UnauthorizedException('Refresh token reuse detected — please log in again');
    }

    await this.refreshTokenRepo.update(stored.id, { revoked: true });

    const user = await this.usersService.findById(payload.sub);
    // A plain refresh call (background token renewal) typically carries
    // no fresh deviceFingerprint from the client - falling back to the
    // rotating-away token's own recorded context means the session
    // shown in "my devices" stays descriptive across silent refreshes,
    // not just at the original login.
    return this.issueTokens(user.id, user.role, {
      deviceFingerprint: context.deviceFingerprint ?? stored.deviceFingerprint ?? undefined,
      ipAddress: context.ipAddress ?? stored.ipAddress ?? undefined,
      userAgent: context.userAgent ?? stored.userAgent ?? undefined,
    });
  }

  /** Revokes a single refresh token (logout on one device). */
  async logout(refreshToken: string): Promise<{ loggedOut: boolean }> {
    const tokenHash = this.hashToken(refreshToken);
    await this.refreshTokenRepo.update({ tokenHash }, { revoked: true });
    return { loggedOut: true };
  }

  /** Revokes every refresh token for a user (logout everywhere). */
  async logoutAll(userId: string): Promise<{ loggedOut: boolean }> {
    await this.refreshTokenRepo.update({ userId, revoked: false }, { revoked: true });
    return { loggedOut: true };
  }

  /**
   * "My devices" / session management - every currently-active login
   * for this user, most recent first. Deliberately excludes revoked
   * and expired sessions - a user reviewing "where am I logged in"
   * wants to see what's actually live, not a full historical log.
   */
  async listSessions(userId: string): Promise<RefreshToken[]> {
    return this.refreshTokenRepo.find({
      where: { userId, revoked: false, expiresAt: MoreThan(new Date()) },
      order: { createdAt: 'DESC' },
    });
  }

  /**
   * Revokes one specific session by id - "log out this device" without
   * logging out everywhere. Scoped to the requesting user: a session
   * id belonging to someone else must fail closed as "not found", not
   * leak whether that id exists at all.
   */
  async revokeSession(userId: string, sessionId: string): Promise<{ loggedOut: boolean }> {
    const result = await this.refreshTokenRepo.update({ id: sessionId, userId, revoked: false }, { revoked: true });
    if (!result.affected) {
      throw new BadRequestException('Session not found');
    }
    return { loggedOut: true };
  }

  private sanitizeUser(user: User) {
    const { passwordHash, ...safe } = user;
    return safe;
  }

  private async issueTokens(userId: string, role: string, context: SessionContext = {}) {
    // A random jti ensures two tokens issued within the same second (e.g.
    // rapid refresh calls) are never byte-identical, since JWT signing is
    // otherwise deterministic for identical payload+iat+secret.
    const payload = { sub: userId, role, jti: randomUUID() };
    const accessExpiresIn = this.config.get<string>('jwt.accessExpiresIn') as any;
    const refreshExpiresIn = this.config.get<string>('jwt.refreshExpiresIn') as any;

    const accessToken = this.jwtService.sign(payload, {
      secret: this.config.get<string>('jwt.accessSecret'),
      expiresIn: accessExpiresIn,
    });
    const refreshToken = this.jwtService.sign(payload, {
      secret: this.config.get<string>('jwt.refreshSecret'),
      expiresIn: refreshExpiresIn,
    });

    await this.refreshTokenRepo.save(
      this.refreshTokenRepo.create({
        userId,
        tokenHash: this.hashToken(refreshToken),
        expiresAt: this.resolveExpiry(refreshExpiresIn),
        deviceFingerprint: context.deviceFingerprint ?? null,
        ipAddress: context.ipAddress ?? null,
        userAgent: context.userAgent ?? null,
      }),
    );

    return { accessToken, refreshToken };
  }

  /**
   * Lets an already-authenticated user add a second role to their existing
   * account (e.g. a passenger who also wants to drive) instead of needing
   * a second account with a different email/phone. Requires the caller to
   * already be authenticated as that user — this is deliberately NOT
   * reachable from the unauthenticated /auth/register endpoint. Which
   * roles are safe to self-add is the same canonical list used by
   * registration itself - see SELF_REGISTERABLE_ROLES's own comment.
   */
  async addRole(userId: string, role: UserRole) {
    if (!SELF_REGISTERABLE_ROLES.includes(role)) {
      throw new BadRequestException(
        `Role "${role}" cannot be self-added. Contact an admin for staff roles.`,
      );
    }
    const user = await this.usersService.addRole(userId, role);
    return this.usersService.sanitize(user);
  }

  private hashToken(token: string): string {
    return createHash('sha256').update(token).digest('hex');
  }

  private resolveExpiry(expiresIn: string): Date {
    const match = /^(\d+)([smhd])$/.exec(expiresIn);
    if (!match) return new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // fallback: 30d
    const value = parseInt(match[1], 10);
    const unitMs = { s: 1000, m: 60000, h: 3600000, d: 86400000 }[match[2]]!;
    return new Date(Date.now() + value * unitMs);
  }
}
